import json, os, subprocess, sys, time
from pathlib import Path
base=Path(__file__).resolve().parent
root=base/'airllm-next'
sys.path.insert(0,str(root/'air_llm'))
from airllm.nextgen.experiment_guard import system_snapshot, ExperimentLimits, admission
samples=[];start=time.monotonic();stable=None
output=base/'resource-window.json'
limits=ExperimentLimits(timeout_seconds=600)
last=None
while time.monotonic()-start<600:
    snap=system_snapshot();now=time.monotonic()
    ready=snap['pressure_level']==1 and snap['available_bytes']>=limits.reserve_bytes+limits.admitted_payload_bytes+(256<<20)
    stable=now if ready and stable is None else stable if ready else None
    samples.append(dict(elapsed_seconds=now-start,ready=ready,**snap))
    output.write_text(json.dumps(dict(status='waiting',samples=samples),indent=2)+'\n')
    state=(ready,snap['pressure_level'])
    if state!=last: print(json.dumps(samples[-1]),flush=True);last=state
    if stable is not None and now-stable>=5: break
    time.sleep(2)
else:
    output.write_text(json.dumps(dict(status='deferred',reason='No stable normal-pressure resource window in 600s; no inference launched',samples=samples),indent=2)+'\n')
    sys.exit(3)
output.write_text(json.dumps(dict(status='admitted',samples=samples),indent=2)+'\n')
subprocess.run([sys.executable,str(base/'hash_model.py'),str(base/'integrity-before.json')],check=True,cwd=root)
command=[sys.executable,str(root/'benchmarks/benchmark_research51.py'),
    '--model','/Users/macbook/.ollama/models/blobs/sha256-f5ee307a2982106a6eb82b62b2c00b575c9072145a759ae4660378acda8dcf2d',
    '--tasks',str(root/'research/hyperstream2/context.json'),'--output',str(base/'profile-baseline/profile.json'),
    '--engine-root',str(base/'baseline'),'--label','profile-baseline',
    '--expert-batch','--concat-tiles','--packed-direct-io','--bulk-metadata','--zero-copy-weights',
    '--expert-pipeline','--string-buffer-bytes','65536','--request-trace','--numerical-evidence']
subprocess.run(command,check=True,cwd=root)
