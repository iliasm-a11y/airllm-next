import hashlib, json, os, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent/'airllm-next/air_llm'))
from airllm.nextgen.experiment_guard import supervise, ExperimentLimits
model = Path('/Users/macbook/.ollama/models/blobs/sha256-f5ee307a2982106a6eb82b62b2c00b575c9072145a759ae4660378acda8dcf2d')
destination = Path(sys.argv[1]).resolve()
if '--worker' in sys.argv:
    before=model.stat(); h=hashlib.sha256()
    with model.open('rb',buffering=0) as f:
        while block:=f.read(1<<20): h.update(block)
    after=model.stat()
    destination.write_text(json.dumps(dict(sha256=h.hexdigest(),bytes=before.st_size,
        stable_file=(before.st_size,before.st_ino,before.st_mtime_ns)==(after.st_size,after.st_ino,after.st_mtime_ns)),indent=2)+'\n')
else:
    supervise([sys.executable,__file__,str(destination),'--worker'],destination,
        ExperimentLimits(admitted_payload_bytes=64<<20,timeout_seconds=120),env=dict(os.environ))
