# CPU16 — première divergence observée face au témoin CPU8

La requête 0 CPU16 a achevé ses 521 tokens de préfill et ses quatre tokens greedy diagnostiques. Elle échoue au critère CPU bit exact inchangé. La campagne complète CPU16 a ensuite été arrêtée volontairement par le superviseur UID ; elle ne constitue pas un bras complet qualifié. La première divergence capturée se situe à la position **512**, indexée depuis zéro, dans **`kda_scan_out-0`**. Les 118 tenseurs logiques observés sont identiques sur les positions 0 à 511.

Le résultat détaillé est dans `work/native-full16-first-divergence.json`. Le calcul est une analyse hors ligne des captures closes, sans modèle chargé, sans GPU, sans compilation, sans changement du helper, du wrapper ou des comparateurs.

## Identité et intégrité des preuves

Les deux requêtes ont le même prompt natif : 521 tokens, SHA-256 des IDs `87148ff9011d3c6662c3ec44274532964b003d236d614bea59994bc12e903730`. Leurs manifestes de dépendances sont égaux après retrait des seuls paramètres `n_batch` et `n_ubatch` : 8 pour le témoin, 16 pour le candidat. CPU10, GPU0, un slot physique et `n_ctx=2048` restent identiques.

Avant comparaison numérique, les SHA-256 et les tailles ont été vérifiés pour **7 788 captures CPU8** et **3 894 captures CPU16**, soit respectivement 627 763 840 et 629 316 160 octets. Cela couvre les 34 sorties KDA originales, les 42 routeurs et les 42 listes d’experts ordonnées, pour chaque lot de la requête 0. Les fichiers `logits-0.f32`, les quatre vecteurs de continuation et les états bruts préfill/après continuation ont également été vérifiés contre leurs SHA enregistrés. Aucun échec d’intégrité n’a été observé.

La comparaison réutilise `_token_compare` de `batch_compare.py` et `tensor_view` de `compare_fidelity.py`. Elle assemble les positions logiques selon les strides GGML : axe 1 pour routeurs/routes, axe 2 pour KDA `[128,64,N,1]`. Le padding des routes stridées ne compte pas comme valeur d’expert. Les sorties KDA suffixées `(reshaped)` ne sont pas assimilées à la sortie originale. Les 118 séries couvrent exactement les 521 positions, sans trou ni chevauchement. Aucun non-fini n’a été trouvé dans ces valeurs comparées.

L’arrêt contrôlé peut laisser une dernière ligne incomplète dans les opérations d’une requête ultérieure : une telle ligne est visible dans `native-full16/capture/operations.jsonl` à la ligne 31 707. Elle n’entre pas dans les tenseurs ni dans la requête 0 comparée. Aucune fin de campagne n’est reconstruite à partir de cette ligne.

## Frontières et état sérialisé complet

Chaque checkpoint porte le hash du même format natif complet `state_seq_flags=0`, avec `next_position=token_end`. L’égalité concerne les octets sérialisés ; elle ne remplace pas les comparaisons de tenseurs.

| Fin exclusive | Octets par bras | Hash CPU8 | Hash CPU16 | Résultat |
|---:|---:|---|---|---|
| 128 | 155 160 708 | `956fd9a155e0…` | identique | exact |
| 208 | 156 739 588 | `4c4d6f24b2cf…` | identique | exact |
| 256 | 157 686 916 | `3996041f59d3…` | identique | exact |
| 384 | 160 213 124 | `9e1b98705542…` | identique | exact |
| 512 | 162 739 332 | `682db949d697…` | identique | exact |
| 521 | 162 916 956 | `6fc9eca51694…` | `c9df5417b888…` | différent |

Les hash complets sont conservés dans le JSON. Les reçus de lots confirment cette dernière découpe : CPU8 traite `[512,520)` puis `[520,521)` ; CPU16 traite `[512,521)` d’un bloc, donc neuf tokens. Les appels précédents des deux bras couvrent les mêmes positions, avec des lots de 8 contre 16.

## Localisation dans les valeurs capturées

À la position 512 et à la couche 0, **6 839 des 8 192 valeurs KDA** diffèrent en bits. L’écart absolu maximal de ce seul tenseur et de ce seul token est `9.313225746154785e-10`. Sa première valeur logique passe de `-3.7347977013268974e-06` (`b67aa356`) à `-3.734801111932029e-06` (`b67aa365`). Ce petit écart ne satisfait pas le critère CPU bit exact ; aucune tolérance Metal n’est substituée à ce critère CPU.

Le premier routeur capturé, couche 3, diverge aussi à la position 512. À cette position, ses huit experts sélectionnés restent toutefois identiques. La première différence de **routes ordonnées**, en triant d’abord par position puis par couche, apparaît à la couche 4 :

```text
position 512, couche 4, CPU8  : 152 201 194 35 273 212 285 22
position 512, couche 4, CPU16 : 152 201 194 35 212 273 285 22
```

Il s’agit ici d’un échange des rangs 4 et 5, indexés depuis zéro, entre les mêmes experts 273 et 212. Dès la position 513, couche 3, l’ensemble sélectionné change également : le dernier expert est 117 dans le témoin et 235 dans CPU16.

La table ci-dessous compte les valeurs logiques différentes en bits à chaque position, pour l’ensemble des couches capturées. Les dénominateurs par position sont 278 528 valeurs KDA, 12 096 valeurs de routeur et 336 IDs d’expert ordonnés.

| Position depuis zéro | KDA différents | Routeurs différents | Rangs d’expert différents | Première couche de routes divergente |
|---:|---:|---:|---:|---:|
| 512 | 275 432 | 12 096 | 56 | 4 |
| 513 | 277 443 | 12 096 | 140 | 3 |
| 514 | 277 508 | 12 096 | 101 | 4 |
| 515 | 277 424 | 12 096 | 142 | 8 |
| 516 | 277 518 | 12 096 | 131 | 6 |
| 517 | 277 520 | 12 096 | 120 | 3 |
| 518 | 277 579 | 12 096 | 131 | 7 |
| 519 | 277 584 | 12 096 | 46 | 4 |
| 520 | 277 219 | 12 096 | 58 | 11 |

Au total, les seules positions 512 à 520 portent 2 495 227 différences KDA, 108 864 différences de routeur et 925 différences de rang d’expert. Aucun de ces décomptes ne prétend comparer les événements d’écriture physiques un à un : les découpes diffèrent. Les états persistants complets sont comparés aux frontières communes et à la fin du prompt.

Le vecteur final contient **154 880/154 880 logits différents**, tous finis, avec un écart absolu maximal `1.6179083585739136` et une RMSE `0.3528993747853432`. Les quatre tokens greedy `[785,1196,374,10156]` restent égaux. En revanche, chaque vecteur complet de continuation diffère sur ses 154 880 valeurs. L’état sérialisé après les trois décodes de continuation diffère aussi (`a17b62e8e6b9…` contre `923e3ca33cd6…`). Quatre argmax égaux ne sont donc pas une preuve de fidélité des logits, de l’état ou d’un EOS utile.

## Hypothèse de la queue impaire dans le runtime V4 exact

La reconstruction source est attestée `source_exact` par `work/metal-integration-v4-source/receipt.json`, sur la révision `3f8af15a76ac8675812e856da45454bafc90f12c`, après les 16 patchs V4. Le manifest de build a pour SHA `7b0ac6dddabf542aae42d7fb8bb8762d6b98e1705dc423b09ad071112d0c8750`. Le fichier `ggml-cpu.c` reconstruit correspond à son SHA attendu `4e2c75dedbf4e074e3d763d94dff956b97508c7c86bfba31e1cf5ddc0060b93e`.

Les points source précis sont les suivants, dans `work/metal-integration-v4-source/source/` :

- `ggml/src/ggml-cpu/ggml-cpu.c:286–295` : `Q8_0` utilise `ggml_vec_dot_q8_0_q8_0`, avec `nrows=2` lorsque `__ARM_FEATURE_MATMUL_INT8` est présent.
- `ggml/src/ggml-cpu/ggml-cpu.c:1518–1526` : le chemin standard force `num_rows_per_vec_dot=1` si `ne11` est impair, ou si la dimension/l’étendue d’un chunk est impaire. Un lot de 9 impose donc `nrc=1`, même pour ses huit premières positions. Le lot de 8 conserve l’éligibilité à `nrc=2` si les autres dimensions restent paires.
- `ggml/src/ggml-cpu/arch/arm/quants.c:1172–1234` : le chemin `nrc=2` fait une somme entière de bloc puis une accumulation flottante par bloc de 32. `:1355–1385` : le chemin NEON `nrc=1` utilise deux accumulateurs flottants partiels puis leurs réductions horizontales. L’ordre arithmétique n’est pas identique.
- `ggml/src/ggml-cpu/ggml-cpu.c:56–58` désactive LLAMAFILE à la compilation sous `MATMUL_INT8`. `ggml/src/ggml-cpu/tiled/tiled.cpp:597–603` refuse le chemin tiled générique sur la cible ARM, qui ne possède pas les macros AVX requises.
- Le `runtime-v4/build.log` conservé, lignes 1148 à 1173, atteste le succès i8mm/MATMUL_INT8 et les options `-U__ARM_FEATURE_SVE -mcpu=native+dotprod+i8mm+nosve+sme`.
- `src/models/glm5-next.cpp:840–884` place les projections Q/K/V puis le calcul récurrent avant le callback `kda_scan_out`. La capture d’opérations à l’offset 512 confirme trois poids Q8_0 `blk.0.attn_q/k/v.weight` et des sorties `[8192,9,1,1]` pour CPU16, contre `[8192,8,1,1]` pour CPU8.

Ces faits confirment **le changement structurel de sélection du chemin standard selon la parité de la queue**. Ils donnent une hypothèse forte cohérente avec la localisation observée, mais ils ne prouvent pas que cette instruction précise soit la première cause du résultat : les valeurs des projections Q/K/V, leur entrée commune et le choix effectif du noyau par opération ne sont pas capturés. Le CPU dispose aussi de mécanismes de dispatch spécialisés. Le premier écart *capturé* est donc établi ; la première instruction arithmétique divergente reste non mesurée.

## Conséquence pour la suite

CPU16 est rejeté avant toute revendication de performance ou de cache. Un restore16 ne réparerait pas cet échec de son témoin sans cache. La prochaine qualification de snapshot conserve le profil **CPU8**, avec restore8 face à full8 et les critères stricts existants. Le cache reste non qualifié jusqu’à une preuve de restauration complète.

Une future variante qui conserverait des lots pairs et traiterait une queue en `8+1`, ou qui figerait une politique arithmétique, constituerait un nouveau protocole. Elle demanderait ses propres témoins complets et comparaisons inchangées, sans réinterpréter la présente campagne ni modifier les sources gelées. Aucun changement de ce type n’a été effectué ici.

Les reçus `native-full16-rejection-prestop.json` et `native-full16-controlled-stop.json` distinguent l’échec numérique mesuré de l’arrêt administratif ultérieur : SIGTERM envoyé au superviseur identifié, sans signal direct envoyé au modèle. Aucun résultat de stabilité à trois requêtes, de replay 0/2, de débit qualifié ou d’EOS fonctionnel n’est déduit du bras interrompu.
