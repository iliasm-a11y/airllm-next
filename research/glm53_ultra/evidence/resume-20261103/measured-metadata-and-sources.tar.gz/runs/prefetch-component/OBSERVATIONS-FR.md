# Prélecture Q8 : observations réelles, portée et décision

**Décision : ne pas intégrer de worker `pread` au moteur sur la base de ces
mesures.** Les deux passages `pread` commencent avec toutes les pages observées
résidentes. Ils ajoutent une préparation de 1,596166 à 1,738583 ms et ne
démontrent aucun gain net. L'hypothèse d'une prélecture utile sur des poids
initialement non résidents reste non mesurée : les seuls passages dans cet état
utilisent `none`.

Cette note relit uniquement les rapports clos et les petites métadonnées
d'alimentation. Elle ne lance ni test, compilation, modèle, lecture de poids ou
nouvelle expérience. Les fichiers gelés de la campagne sont conservés.

## Conditions et contrôles

Sources : [standard-once.json](standard-once.json),
[nocache-once.json](nocache-once.json),
[contrôle alimentation standard](../prefetch-standard-power.json) et
[contrôle alimentation nocache](../prefetch-nocache-power.json).
Exécutions du 3 novembre 2026 vers **08 h 42, Europe/Paris**.

Même matrice originale `blk.0.attn_q.weight`, Q8_0 `[4096,8192]`,
**35 651 584 octets**, au décalage absolu **1 590 187 712** du deuxième shard
Q2_K_S épinglé. L'activation FP32 réelle est celle de `attn_norm-40`, étape 1 de
la capture antérieure ; sa largeur convient au poids de couche 0, mais cette
paire ne rejoue pas une opération réelle de couche 0 du modèle complet.

Chaque série suit l'ordre fixe **none → pread → willneed → none**. Chaque bras
utilise un nouveau processus, un pool CPU10 persistant pour ses deux phases,
un mapping en lecture seule et le même scratch de 8 Mio, même quand il n'est
pas utilisé. La phase 0 observe le mode choisi ; la phase 1 recalcule sans
préparation dans le même processus pour comparer les bits sur un mapping
observé entièrement résident. Il n'y a ni purge ni contrôle préalable du cache.

`standard` correspond au mapping partagé normal ; `nocache` ajoute
`MAP_NOCACHE`. Le mode `pread` effectue cinq lectures normales, pour exactement
35 651 584 octets logiques, dans le scratch réutilisé. Aucun `F_NOCACHE` de
descripteur n'est demandé. `willneed` appelle
`posix_madvise(POSIX_MADV_WILLNEED)` sur le mapping ; il ne copie pas les poids
dans ce scratch. Ces réglages ont des sémantiques distinctes.

Les deux rapports sont `complete`, sans violation de garde ni croissance
échantillonnée du swap. Pics RSS : **51 150 848 octets** en standard et
**51 183 616 octets** en nocache, sous le plafond de 256 Mio. La pression est
normale au début et à la fin. Les wrappers d'alimentation réussissent avec cinq
échantillons chacun, secteur et couvercle ouvert, sans dérive d'horloge détectée
au seuil fixé. Ces observations ne constituent pas une mesure thermique ni
une preuve continue de tous les événements d'alimentation.

Les seize vecteurs de sortie des deux séries — **131 072 valeurs FP32** au
total — concordent dans les rapports, bit à bit entre phases et avec le hash
historique. Les identités de fichiers restent inchangées ; les dix hashes de
bibliothèques V4 vérifiés avant/après sont identiques. La preuve concerne ce
produit de matrice, pas les logits, routes ou états KDA d'une inférence complète.

## Temps : séparer les régimes de résidence

Toutes les durées ci-dessous sont en **millisecondes** et proviennent de la
phase 0. Chaque mapping contient **2 177 pages de 16 384 octets**, pages de bord
comprises. Les nombres de pages sont les observations instantanées de
`mincore`, pas des taux de hits ni des garanties de rétention.

« Préparation + calcul » additionne leurs deux intervalles chronométrés.
L'observation des compteurs et de la résidence après préparation crée un
intervalle explicite avant le calcul. Le « total observé » inclut aussi cet
intervalle, mais pas la création du pool, du mapping ou du scratch. Cet
intervalle peut laisser progresser une opération asynchrone : ces temps sont
ceux du diagnostic instrumenté.

### Passages initialement non résidents selon `mincore`

| Mapping / bras | Mode | Pages avant → après préparation → après calcul | Préparation | Calcul | Préparation + calcul | Intervalle d'observation | Total observé |
|---|---|---|---:|---:|---:|---:|---:|
| standard / 0 | none | 0 → 0 → 2 177 | 0,000000 | 14,156541 | 14,156541 | 0,579500 | 14,736041 |
| nocache / 0 | none | 0 → 0 → 2 177 | 0,000042 | 14,427750 | 14,427792 | 0,678167 | 15,105959 |

Ces deux passages comptabilisent chacun **35 672 064 octets de lectures OS du
PID** et **2 177 pageins**, pendant le calcul. Ils ne prouvent pas un cache
physiquement froid ni un volume NAND. Il n'existe ici **aucun passage `pread`
ou `willneed` commençant à zéro page résidente** auquel les comparer.

### Passages initialement entièrement résidents selon `mincore`

Toutes les observations de pages avant/après préparation/après calcul restent
à 2 177 pour les six lignes suivantes.

| Mapping / bras | Mode | Préparation | Calcul | Préparation + calcul | Intervalle d'observation | Total observé |
|---|---|---:|---:|---:|---:|---:|
| standard / 1 | pread | 1,738583 | 4,133125 | 5,871708 | 0,850958 | 6,722666 |
| standard / 2 | willneed | 0,698125 | 0,336000 | 1,034125 | 0,557666 | 1,591791 |
| standard / 3 | none | 0,000000 | 0,687291 | 0,687291 | 0,519042 | 1,206333 |
| nocache / 1 | pread | 1,596166 | 0,824209 | 2,420375 | 0,809375 | 3,229750 |
| nocache / 2 | willneed | 0,699500 | 0,323792 | 1,023292 | 0,523458 | 1,546750 |
| nocache / 3 | none | 0,000000 | 2,117166 | 2,117166 | 0,520334 | 2,637500 |

À titre descriptif, `pread` dépasse le contrôle `none` entièrement résident de
**5,184417 ms** en standard et de **0,303209 ms** en nocache sur la somme
préparation + calcul. Ce sont deux différences de passages uniques, pas une
estimation causale ou une distribution de performance. Le résultat `willneed`
nocache est inférieur à son contrôle tardif ; l'effectif, l'ordre et la
variabilité interdisent d'en qualifier un gain général.

Les médianes `none` mélangeant les bras 0 et 3 sont volontairement exclues de
cette comparaison : elles combineraient zéro et 2 177 pages initiales. Leur
comparaison brute aux candidats déjà résidents fabriquerait une impression
d'accélération du stockage.

## Ce que révèlent les compteurs

Toujours pour la phase 0 ; les lectures sont une comptabilité OS du PID, pas du
trafic physique attribué au SSD ou des cellules NAND.

| Mapping / mode | Lectures OS préparation / calcul, octets | Pageins préparation / calcul | Fautes du processus préparation / calcul |
|---|---:|---:|---:|
| standard / none, bras 0 | 0 / 35 672 064 | 0 / 2 177 | 1 / 2 188 |
| standard / pread | 2 113 536 / 0 | 0 / 0 | 1 / 2 184 |
| standard / willneed | 0 / 0 | 0 / 0 | 2 178 / 10 |
| standard / none, bras 3 | 0 / 0 | 0 / 0 | 1 / 2 184 |
| nocache / none, bras 0 | 0 / 35 672 064 | 0 / 2 177 | 1 / 2 192 |
| nocache / pread | 2 113 536 / 0 | 0 / 0 | 1 / 2 185 |
| nocache / willneed | 0 / 0 | 0 / 0 | 2 178 / 15 |
| nocache / none, bras 3 | 0 / 0 | 0 / 0 | 1 / 2 185 |

Dans ces passages, `pread` n'élimine pas les quelque 2 184–2 185 fautes
observées pendant le calcul. `willneed` les déplace essentiellement dans la
préparation. Le RSS après préparation est **15 319 040 octets** pour les deux
bras `pread`, contre **50 970 624 / 50 987 008 octets** pour `willneed`
standard/nocache. Cela concorde avec une installation anticipée des pages dans
le mapping par `willneed`, sans assimiler ce RSS à une nouvelle copie privée
des poids. Les fautes comprennent aussi d'autres pages du processus.

Les **2 113 536 octets OS** comptés dans chaque préparation `pread`, malgré
l'observation initiale de résidence complète, ne permettent pas d'affirmer une
lecture « exclusivement RAM ». Du readahead ou d'autres effets de comptabilité
peuvent contribuer ; leur attribution exacte n'est pas mesurée ici. Ils ne
doivent pas être convertis en lectures NAND ni soustraits des octets logiques
pour construire un taux de hits.

## Références répétées : fidélité et variabilité

Les calculs de phase 1 ci-dessous sont tous `none`, avec toutes les pages
observées résidentes et **zéro lecture OS, pagein et faute** comptabilisés sur
leur intervalle de calcul. Le pool est déjà utilisé dans le même processus.

| Mapping | Après bras none 0 | Après pread | Après willneed | Après bras none 3 |
|---|---:|---:|---:|---:|
| standard, calcul ms | 0,318209 | 0,328375 | 0,978708 | 1,522292 |
| nocache, calcul ms | 0,337125 | 0,339125 | 0,647959 | 0,462625 |

La variabilité persiste sans lecture OS attribuée au calcul. Ces valeurs ne
prouvent pas un coût d'I/O caché ; elles peuvent inclure ordonnancement, caches
matériels, état du pool et fréquences, sans attribution mesurée à une cause
particulière. Les moyennes ou rapports entre quelques valeurs ne deviennent
pas une preuve d'accélération soutenue du modèle.

## Conséquence pour le moteur

Ces essais établissent la fidélité du composant et le coût explicite de sa
préparation. Ils ne montrent ni recouvrement calcul/I/O par un worker, ni
réduction des lectures de poids initialement non résidents, ni gain de tokens
corrects par seconde. La copie vers le scratch et son coût CPU/mémoire ne
disparaîtraient pas dans une implémentation asynchrone ; leur masquage éventuel
et la contention supplémentaire restent inconnus.

Le résultat ne réfute donc pas toute prélecture exacte possible, mais il
**ne justifie pas l'intégration d'un worker `pread` maintenant**. La voie
actuelle est conservée. Une réouverture exigerait un composant ayant des
conditions initiales comparables sur le régime non résident et un gain sur le
coût complet, puis une mesure alternée du modèle avec fidélité et protections
inchangées. La présence de quelques millisecondes gagnées au seul calcul,
après une préparation exclue du chronomètre, ne remplirait pas ce critère.

## Empreintes des preuves relues

| Élément | SHA-256 |
|---|---|
| `standard-once.json` | `6589d6c6b5e00d2988a938337db9a2bd015f1186f9cc3cf42240d67080094c82` |
| `nocache-once.json` | `96597bfbee25f93c83e098499693849b6b7ee3519b22e2ef50e78cbfce05884e` |
| Binaire du composant commun enregistré | `24044347a353044d604efea15592d24ff9957351ed278bb3ecf66c93f9132c0a` |
| Activation réelle | `495aaba3baa5a0580b775c7cc5f899a27f60e0b149caead97a776974796b45fe` |
| Chaque vecteur de 8 192 sorties | `4d43f62056d934601a565fda2726017c92f573474cd8cccf9783e318d2dea30d` |

Les hashes des deux JSON ont été calculés lors de cette relecture. Les hashes
de binaire, d'activation, des bibliothèques et des sorties sont ceux contrôlés
et enregistrés par les exécutions closes ; ils n'ont pas été recalculés par un
nouveau passage matériel pendant cette analyse.
