#!/usr/bin/env python3
"""Bounded GLM native benchmark; counters describe their actual measurement scope."""
from __future__ import annotations

import argparse
import ctypes
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import plistlib
import signal
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.request

import psutil
from research.glm53_gpu_v2.storage_counters import block_snapshot, compare_snapshots, parse_gpu_times
from research.glm53_gpu_v2.benchmark_lifecycle import owned_server, stop_owned_server, stop_for_guard, account_final_swap, interrupt_on_sigterm

from .system_memory import SystemMemoryObserver
from .process_io import ProcessIOObserver
from .dense_lock_plan import load_plan, lock_environment, check_plan, retained_log
from .completion_contract import record_server_exit, validate_completion
from .power_state import PowerGate, ScopedAwake

GIB = 1024**3


class Usage(ctypes.Structure):
    _fields_ = [('uuid', ctypes.c_uint8 * 16)] + [(n, ctypes.c_uint64) for n in (
        'user_ticks', 'system_ticks', 'idle_wakeups', 'interrupt_wakeups', 'pageins',
        'wired', 'resident', 'footprint', 'start', 'exit', 'child_user', 'child_system',
        'child_idle', 'child_interrupt', 'child_pageins', 'child_elapsed',
        'storage_read_bytes', 'storage_write_bytes')]


LIBPROC = ctypes.CDLL('/usr/lib/libproc.dylib')
LIBPROC.proc_pid_rusage.argtypes = (ctypes.c_int, ctypes.c_int, ctypes.c_void_p)


def usage(pid):
    value = Usage()
    if LIBPROC.proc_pid_rusage(pid, 2, ctypes.byref(value)):
        return None
    return {name: int(getattr(value, name)) for name in (
        'user_ticks', 'system_ticks', 'pageins', 'resident', 'footprint',
        'storage_read_bytes', 'storage_write_bytes')}


def command_text(args):
    return subprocess.run(args, capture_output=True, text=True, timeout=5).stdout.strip()


def pressure():
    value = command_text(['/usr/sbin/sysctl', '-n', 'kern.memorystatus_vm_pressure_level'])
    if not value or int(value) not in (1, 2, 4):
        raise RuntimeError('Cannot measure memory pressure')
    return int(value)


def gpu_stats():
    try:
        data = subprocess.run(['/usr/sbin/ioreg', '-a', '-r', '-d', '1', '-c', 'IOAccelerator'],
                              capture_output=True, timeout=5).stdout
        return plistlib.loads(data)[0].get('PerformanceStatistics', {})
    except (OSError, ValueError, IndexError, plistlib.InvalidFileException):
        return None


def atomic_save(path, value):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    tmp.replace(path)


def request(base, endpoint, body=None, timeout=1200):
    data = json.dumps(body).encode() if body is not None else None
    return urllib.request.urlopen(urllib.request.Request(base + endpoint, data=data,
        headers={'Content-Type': 'application/json'}), timeout=timeout)


def run(args):
    if args.output.exists() or args.output.with_suffix('.log').exists():
        raise ValueError('Refusing to overwrite benchmark evidence')
    gate = PowerGate(getattr(args, 'expected_power_source', None))
    preflight = gate.sample()
    if not preflight['passed']:
        report = {'schema_version': 1, 'status': 'failed', 'error': 'Awake/power preflight declined',
                  'power_gate': gate.summary(), 'model_launched': False}
        args.output.parent.mkdir(parents=True, exist_ok=True)
        atomic_save(args.output, report)
        return report
    dense_lock = load_plan(args.dense_lock_plan, args.model) if getattr(args, 'dense_lock_plan', None) else None
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]
    command = [str(args.binary.resolve()), '--offline', '--fit', 'off', '-m', str(args.model),
        '--load-mode', 'mmap', '--no-repack', '--no-warmup', '--ctx-size', str(args.context),
        '-b', str(args.batch), '-ub', str(args.batch), '-t', str(args.threads), '-tb', str(args.threads),
        '-ngl', str(args.gpu_layers), '-np', '1', '--host', '127.0.0.1', '--port', str(port),
        '--no-webui', '--no-mmproj', '--no-context-shift', '--perf', '--log-colors', 'off']
    if args.gpu_layers == 0 and not args.head_only and not args.quant_tail:
        command += ['--device', 'none', '--no-op-offload']
    if args.head_only:
        command += ['--device', 'MTL0', '--override-tensor', '^output\\.weight$=MTL0', '--no-op-offload', '--no-kv-offload']
    placement = None
    if args.quant_tail:
        from research.glm53_gpu_v2.placement import plan
        placement = plan(args.quant_tail)
        command += ['--device', 'MTL0', '--override-tensor', placement['tensor_pattern']+'=MTL0', '--no-op-offload', '--no-kv-offload']
    if args.cpu_moe:
        command += ['--cpu-moe', '--moe-cache-mib', str(args.moe_cache_mib)]
    if getattr(args, 'weights_only', False):
        command += ['--no-op-offload', '--no-kv-offload']
    command += args.extra
    report = dict(schema_version=1, started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        status='running', command=command, model_revision='119034bc3d9d76eb41f91508e6f9fb19fde42672',
        binary_sha256=hashlib.sha256(args.binary.read_bytes()).hexdigest(),
        runner_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        runner_lifecycle_source_sha256=hashlib.sha256((Path(__file__).resolve().parents[1] / 'glm53_gpu_v2/benchmark_lifecycle.py').read_bytes()).hexdigest(),
        cache_scope='Process cold at launch; OS file cache uncontrolled. Repeats share process, KV reuse disabled.',
        hardware=command_text(['/usr/sbin/sysctl', 'hw.model', 'hw.memsize', 'machdep.cpu.brand_string']),
        os=command_text(['/usr/bin/sw_vers']), logical_weight_reads_bytes=None, physical_nand_reads_bytes=None,
        storage_scope='libproc process OS-accounted I/O, includes paging and readahead; not NAND bytes',
        gpu_scope='IORegistry system-wide utilization; includes desktop and other processes',
        cpu_counter_scope='rusage user/system are mach absolute ticks; multiply by 125/3 for nanoseconds on this M5',
        component_timings={'dequantization': None, 'router': None, 'gpu_compute': None,
            'synchronization': None, 'allocation': None},
        thermal_before=command_text(['/usr/bin/pmset', '-g', 'therm']),
        samples=[], requests=[], guard_violation=None, peak_rss_bytes=0, peak_footprint_bytes=0,
        swap_start_bytes=psutil.swap_memory().used, peak_swap_growth_bytes=0)
    report['native_libraries_sha256'] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
        for p in args.binary.resolve().parent.glob('*.dylib') if not p.is_symlink()}
    atomic_save(args.output, report)
    stop = threading.Event()
    t0 = time.perf_counter()
    env = {k: v for k, v in os.environ.items() if not k.startswith(('LLAMA_ARG_', 'AIRLLM_', 'GGML_', 'DYLD_'))}
    env.pop('LLAMA_API_KEY', None)
    report['model_file_stats_before'] = [{'file':p.name,'size':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns}
        for p in sorted(args.model.parent.glob('*.gguf'))]
    report['mmap_demand'] = args.mmap_demand
    report['expert_prefetch'] = args.expert_prefetch
    report['dense_prefetch'] = args.dense_prefetch
    if args.mmap_demand:
        env['AIRLLM_MMAP_DEMAND'] = '1'
    if args.expert_prefetch:
        env['AIRLLM_EXPERT_PREFETCH'] = '1'
    if args.dense_prefetch:
        env['AIRLLM_DENSE_PREFETCH'] = '1'
    report['research_environment'] = {}
    if dense_lock:
        report['dense_lock_plan'] = dense_lock
        env.update(lock_environment(dense_lock))
        report['research_environment'].update(lock_environment(dense_lock))
    report['head_only'] = args.head_only
    report['placement'] = placement
    for option, variable in (('q8_cpu_arith', 'AIRLLM_METAL_Q8_CPU_ARITH'), ('metal_timing', 'AIRLLM_METAL_COMMAND_TIMING'), ('q8_shared', 'AIRLLM_METAL_Q8_SHARED'), ('mapped_cpu_weights', 'AIRLLM_METAL_CPU_MAPPED_WEIGHTS'), ('expert_drop', 'AIRLLM_EXPERT_DROP_AFTER_USE')):
        if getattr(args, option, False):
            env[variable] = '1'
            report['research_environment'][variable] = '1'
    if args.quant_tail:
        env.update(AIRLLM_METAL_Q8_CPU_ARITH='2', AIRLLM_GLM_Q8_ONLY='1')
        report['research_environment'].update(AIRLLM_METAL_Q8_CPU_ARITH='2', AIRLLM_GLM_Q8_ONLY='1')
    for option, variable in (('layer_local_hc', 'AIRLLM_GLM_LAYER_LOCAL_HC'),
                             ('cache_lookup_split', 'AIRLLM_GLM_CACHE_SPLIT')):
        if getattr(args, option, False):
            env[variable] = '1'
            report['research_environment'][variable] = '1'
    if args.interposer:
        env['DYLD_INSERT_LIBRARIES'] = str(args.interposer.resolve())
    for option, variable in (('mmap_nocache', 'AIRLLM_MMAP_NOCACHE'), ('dense_lookahead', 'AIRLLM_DENSE_LOOKAHEAD')):
        if getattr(args, option, False):
            env[variable] = '1'; report['research_environment'][variable] = '1'
    if getattr(args, 'dense_lookahead', False):
        env['AIRLLM_DENSE_LOOKAHEAD_MIB'] = str(args.lookahead_mib)
        report['research_environment']['AIRLLM_DENSE_LOOKAHEAD_MIB'] = str(args.lookahead_mib)
    system_observer = SystemMemoryObserver()
    report['system_before'] = system_observer.snapshot()
    if dense_lock:
        report['dense_lock_prelaunch'] = check_plan(dense_lock, args.model)
    watcher = None
    awake = None
    def finalized(child, error):
        stop.set()
        if watcher is not None and watcher.is_alive():
            watcher.join(timeout=6)
        if error is not None:
            report.update(status='failed', error_type=type(error).__name__, error=str(error))
        if child is not None:
            report['exit_code'] = child.returncode
            record_server_exit(report, child.returncode)
            if child.poll() is None:
                report.update(status='failed', error='Owned server cleanup did not finish')
        final_power = gate.sample(final=True)
        report['power_gate'] = gate.summary()
        if awake is not None:
            report['power_gate']['idle_assertion'] = dict(awake.record)
        if (not final_power['passed'] or not report['power_gate']['passed'] or
                awake is None or not awake.record.get('cleaned_up')):
            report.update(status='failed', power_error='Awake assertion or clock/power continuity failed')
        account_final_swap(report, psutil.swap_memory().used)
        atomic_save(args.output, report)
    if not gate.sample()['passed']:
        report.update(status='failed', error='Awake/power admission changed before launch', power_gate=gate.summary())
        atomic_save(args.output, report)
        return report
    with args.output.with_suffix('.log').open('w') as log, owned_server(
            command, stdout=log, env=env, after_cleanup=finalized) as child, ScopedAwake(child) as awake:
        report['owned_pid'] = child.pid
        process = psutil.Process(child.pid)
        process_observer = ProcessIOObserver(child.pid)
        def monitor():
            tick = 0
            try:
                while not stop.wait(.5) and child.poll() is None:
                    mem = psutil.virtual_memory()
                    rss = process.memory_info().rss
                    counters = usage(child.pid)
                    swap = psutil.swap_memory().used
                    awake.check()
                    power_check = gate.sample(include_power=tick % 4 == 0)
                    row = dict(t=time.perf_counter()-t0, rss=rss, available=mem.available,
                               swap_used=swap, process=counters, power_check=power_check,
                               cpu_seconds=sum(process.cpu_times()[:2]))
                    if tick % 4 == 0:
                        row['pressure'] = pressure()
                        row['gpu_system'] = gpu_stats()
                        row['block_device'] = block_snapshot()
                        row['system_memory'] = system_observer.snapshot()
                        row['owned_process'] = process_observer.snapshot()
                    report['samples'].append(row)
                    report['peak_swap_growth_bytes'] = max(report['peak_swap_growth_bytes'], swap-report['swap_start_bytes'])
                    if tick % 4 == 0:
                        atomic_save(args.output.with_suffix('.progress.json'), row)
                    report['peak_rss_bytes'] = max(report['peak_rss_bytes'], rss)
                    if counters:
                        report['peak_footprint_bytes'] = max(report['peak_footprint_bytes'], counters['footprint'])
                    if (not power_check['passed'] or rss > args.max_rss_gib * GIB or mem.available < 256 * 1024**2
                            or swap - report['swap_start_bytes'] > args.max_swap_mib * 1024**2
                            or row.get('pressure') == 4 or row['t'] > args.timeout):
                        stop_for_guard(child, report, row)
                        return
                    tick += 1
            except psutil.NoSuchProcess:
                pass
            except Exception as exc:
                stop_for_guard(child, report, {'monitor_error': str(exc)})
        watcher = threading.Thread(target=monitor, daemon=True)
        watcher.start()
        base = f'http://127.0.0.1:{port}'
        try:
            while True:
                if child.poll() is not None:
                    raise RuntimeError('Server stopped before ready')
                try:
                    with request(base, '/health', timeout=1) as response:
                        if response.status == 200:
                            break
                except (OSError, urllib.error.HTTPError):
                    pass
                if time.perf_counter() - t0 > 180:
                    raise TimeoutError('Server load timeout')
                time.sleep(.2)
            report['load_seconds'] = time.perf_counter()-t0
            for rep in range(args.repeats):
                body = dict(prompt=args.prompt, n_predict=args.tokens, temperature=0,
                    seed=42, stream=True, cache_prompt=False, return_tokens=True,
                    n_probs=args.n_probs, timings_per_token=True)
                row = dict(repetition=rep, body=body, events=[], usage_before=usage(child.pid))
                row['block_device_before'] = block_snapshot()
                row['gpu_command_count_before'] = parse_gpu_times(args.output.with_suffix('.log'))['recorded_commands']
                report['requests'].append(row)
                start = time.perf_counter()
                row['start_since_launch_seconds'] = start-t0
                first = None
                with request(base, '/completion', body) as response:
                    for raw in response:
                        line = raw.decode().strip()
                        if not line.startswith('data: ') or line == 'data: [DONE]':
                            continue
                        event = json.loads(line[6:])
                        now = time.perf_counter()
                        row['events'].append(dict(t=now-start, response=event))
                        if event.get('tokens') and first is None:
                            first = now
                            row['ttft_seconds'] = first-start
                        if event.get('tokens'):
                            count = sum(len(e['response'].get('tokens', [])) for e in row['events'])
                            atomic_save(args.output.with_suffix('.stream-progress.json'),
                                {'generated_token_ids': count, 'request_elapsed_seconds': now-start,
                                 'first_token_seconds': row.get('ttft_seconds'), 'last_ids': event['tokens']})
                        if event.get('stop'):
                            row['final'] = event
                            break
                row['wall_seconds'] = time.perf_counter()-start
                row['usage_after'] = usage(child.pid)
                row['gpu_command_times'] = parse_gpu_times(args.output.with_suffix('.log'), row['gpu_command_count_before'])
                row['block_device_after'] = block_snapshot()
                row['block_device_delta'] = compare_snapshots(row['block_device_before'], row['block_device_after'])
                row['tokens'] = [token for event in row['events'] for token in event['response'].get('tokens', [])]
                row['text'] = ''.join(event['response'].get('content', '') for event in row['events'])
                emitted = [e['t'] for e in row['events'] if e['response'].get('tokens') and not e['response'].get('stop')]
                row['inter_token_seconds'] = [b-a for a, b in zip(emitted, emitted[1:])]
                row['observed_decode_tokens_per_second'] = ((len(emitted)-1)/(emitted[-1]-emitted[0])
                    if len(emitted) > 1 and emitted[-1] > emitted[0] else None)
                if not row.get('final', {}).get('stop'):
                    raise RuntimeError('Missing terminal SSE event')
                row['completion_contract'] = validate_completion(row, args.tokens)
                if not row['completion_contract']['passed']:
                    raise RuntimeError('Terminal completion/count contract rejected this request')
                atomic_save(args.output, report)
                print(json.dumps(dict(output=str(args.output), repetition=rep, tokens=len(row['tokens']),
                    ttft=row.get('ttft_seconds'), decode=row['observed_decode_tokens_per_second'],
                    timings=row['final'].get('timings'))), flush=True)
            if report['guard_violation'] is not None:
                raise RuntimeError('Memory/process guard rejected this run')
            report['status'] = 'complete'
        except Exception as exc:
            report.update(status='failed', error_type=type(exc).__name__, error=str(exc))
        finally:
            report['usage_final'] = usage(child.pid)
            final_power = gate.sample(final=True)
            if not final_power['passed']:
                report.update(status='failed', power_error='Clock/power continuity failed at request cleanup')
            stop.set()
            watcher.join(timeout=6)
            if report['guard_violation'] is not None:
                report['status'] = 'failed'
            stop_owned_server(child)
            record_server_exit(report, child.returncode)
            report.update(exit_code=child.returncode, total_seconds=time.perf_counter()-t0,
                thermal_after=command_text(['/usr/bin/pmset', '-g', 'therm']))
            account_final_swap(report, psutil.swap_memory().used)
            atomic_save(args.output, report)
    report['system_after'] = system_observer.snapshot()
    report['model_file_stats_unchanged'] = all((args.model.parent/r['file']).stat().st_size == r['size'] and
        (args.model.parent/r['file']).stat().st_mtime_ns == r['mtime_ns'] for r in report['model_file_stats_before'])
    if not report['model_file_stats_unchanged']:
        report['status'] = 'failed'
        report['error'] = 'Model file stats changed'
    report['gpu_command_times'] = parse_gpu_times(args.output.with_suffix('.log'))
    if dense_lock:
        report['dense_lock'] = retained_log(args.output.with_suffix('.log'), dense_lock)
        try:
            report['dense_lock_postrun'] = check_plan(dense_lock, args.model)
        except (ValueError, OSError) as error:
            report['dense_lock_postrun'] = {'passed': False, 'error': str(error)}
        if not report['dense_lock']['passed'] or not report['dense_lock_postrun']['passed']:
            report.update(status='failed', error='Bounded dense lock retention/selector identity was not proved')
    atomic_save(args.output, report)
    return report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--expected-power-source', choices=('ac', 'battery'), help='Campaign admission source; a change rejects timing')
    p.add_argument('--mmap-nocache', action='store_true')
    p.add_argument('--dense-lookahead', action='store_true')
    p.add_argument('--dense-lock-plan', type=Path, help='Default-off bounded original dense mmap retention selector')
    p.add_argument('--lookahead-mib', type=int, choices=(16,32,64,128), default=32)
    p.add_argument('--binary', type=Path, required=True)
    p.add_argument('--model', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--prompt', default='La capitale de la France est')
    p.add_argument('--tokens', type=int, default=16)
    p.add_argument('--context', type=int, default=512)
    p.add_argument('--batch', type=int, default=8)
    p.add_argument('--threads', type=int, default=4)
    p.add_argument('--gpu-layers', type=int, default=0)
    p.add_argument('--cpu-moe', action='store_true')
    p.add_argument('--moe-cache-mib', type=int, default=0)
    p.add_argument('--repeats', type=int, default=1)
    p.add_argument('--n-probs', type=int, default=8)
    p.add_argument('--timeout', type=int, default=1800)
    p.add_argument('--max-rss-gib', type=float, default=8.5)
    p.add_argument('--interposer', type=Path)
    p.add_argument('--mmap-demand', action='store_true')
    p.add_argument('--expert-prefetch', action='store_true')
    p.add_argument('--dense-prefetch', action='store_true')
    p.add_argument('--head-only', action='store_true')
    p.add_argument('--expert-drop', action='store_true')
    p.add_argument('--q8-shared', action='store_true')
    p.add_argument('--mapped-cpu-weights', action='store_true')
    p.add_argument('--quant-tail', type=int, default=0)
    p.add_argument('--q8-cpu-arith', action='store_true')
    p.add_argument('--metal-timing', action='store_true')
    p.add_argument('--max-swap-mib', type=float, default=32)
    p.add_argument('--weights-only', action='store_true', help='Disable opportunistic GPU ops and KV offload')
    p.add_argument('--layer-local-hc', action='store_true', help='Experimental patched GLM HC placement')
    p.add_argument('--cache-lookup-split', action='store_true', help='Experimental patched MoE dependency split')
    p.add_argument('extra', nargs='*')
    args = p.parse_args()
    if args.context < 128 or args.tokens < 1 or args.batch < 1 or not 0 < args.max_rss_gib <= 8.5 or not 0 < args.max_swap_mib <= 64:
        p.error('Unsafe or invalid limits')
    if (args.head_only or args.quant_tail) and args.gpu_layers:
        p.error('head-only requires gpu-layers0')
    if args.head_only and args.quant_tail or args.q8_shared and (not args.head_only or not args.q8_cpu_arith):
        p.error('Incompatible placement modes')
    with Path('/tmp/airllm-glm53-benchmark.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        with interrupt_on_sigterm():
            report = run(args)
    raise SystemExit(0 if report['status'] == 'complete' else 1)


if __name__ == '__main__':
    main()
