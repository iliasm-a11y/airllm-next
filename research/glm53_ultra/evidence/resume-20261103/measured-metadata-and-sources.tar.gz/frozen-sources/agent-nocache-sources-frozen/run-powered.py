"""Observe AC/lid/clock continuity around an already guarded owned diagnostic."""
import argparse
import json
import signal
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "airllm-next"))
from research.glm53_gpu_v3.power_state import PowerGate, ScopedAwake

p = argparse.ArgumentParser()
p.add_argument("--report", type=Path, required=True)
p.add_argument("command", nargs=argparse.REMAINDER)
a = p.parse_args()
command = a.command[1:] if a.command[:1] == ["--"] else a.command
if not command or a.report.exists():
    p.error("New report and owned guarded command required")
gate = PowerGate("ac")
report = {"scope": "power observer around an independently memory-guarded diagnostic", "command": command}
child = awake = None
try:
    if not gate.sample()["passed"]:
        raise RuntimeError("AC/open-lid admission rejected")
    child = subprocess.Popen(command)
    report["owned_supervisor_pid"] = child.pid
    awake = ScopedAwake(child)
    awake.__enter__()
    while child.poll() is None:
        if not gate.sample()["passed"]:
            raise RuntimeError("Power context or clock changed")
        try:
            awake.check()
        except Exception:
            if child.poll() is None:
                raise
        time.sleep(.5)
    report["returncode"] = child.returncode
except BaseException as error:
    report["error"] = type(error).__name__ + ": " + str(error)
finally:
    if child is not None and child.poll() is None:
        for sig, timeout in ((signal.SIGINT, 10), (signal.SIGTERM, 5), (signal.SIGKILL, 5)):
            if child.poll() is not None:
                break
            child.send_signal(sig)
            try:
                child.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                pass
        report["returncode"] = child.poll()
    if awake is not None:
        try:
            awake.close()
        except Exception as error:
            report["awake_cleanup_error"] = str(error)
        report["idle_assertion"] = awake.record
    gate.sample(final=True)
    report["power_gate"] = gate.summary()
    report["passed"] = (report.get("returncode") == 0 and gate.summary()["passed"]
                        and "error" not in report and "awake_cleanup_error" not in report)
    a.report.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"power_report": str(a.report), "passed": report["passed"]}))
sys.exit(0 if report["passed"] else 2)
