import hashlib
import json
import os
from pathlib import Path
import sys
from time import perf_counter

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'airllm-next/air_llm'))
from airllm.nextgen.physical_io import set_fd_nocache, physical_read_bytes

expected='f5ee307a2982106a6eb82b62b2c00b575c9072145a759ae4660378acda8dcf2d'
path=Path('/Users/macbook/.ollama/models/blobs/sha256-'+expected)
destination=ROOT/'model-integrity-after.json'
before=path.stat()
fd=os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
digest=hashlib.sha256();total=0;read_seconds=0.;begin=perf_counter();physical_before=physical_read_bytes()
try:
    set_fd_nocache(fd)
    opened=os.fstat(fd)
    while True:
        read_begin=perf_counter();block=os.read(fd,4<<20);read_seconds+=perf_counter()-read_begin
        if not block:break
        digest.update(block);total+=len(block)
    after=os.fstat(fd)
finally:
    os.close(fd)
identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
stable=identity(before)==identity(opened)==identity(after)==identity(path.stat())
report=dict(kind='complete_readonly_streaming_sha256',sha256=digest.hexdigest(),bytes=total,
    file_identity=identity(before),stable_file=stable,expected_sha256=expected,
    matched=stable and digest.hexdigest()==expected and total==23938321664,
    physical_process_read_bytes=physical_read_bytes()-physical_before,read_syscall_seconds=read_seconds,
    seconds=perf_counter()-begin,io_policy='F_NOCACHE on own O_RDONLY fd; no cache purge; no NAND bandwidth claim')
with destination.open('x') as stream:json.dump(report,stream,indent=2)
print(json.dumps(report),flush=True)
if not report['matched']:raise RuntimeError('Model integrity verification failed')
