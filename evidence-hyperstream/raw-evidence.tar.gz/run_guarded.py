import argparse
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'airllm-next/air_llm'))
from airllm.nextgen.experiment_guard import ExperimentLimits, supervise

parser=argparse.ArgumentParser()
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--payload-mib', type=int, default=768)
parser.add_argument('command', nargs=argparse.REMAINDER)
args=parser.parse_args()
command=args.command[1:] if args.command[0]=='--' else args.command
if any(args.output.with_suffix(suffix).exists() for suffix in ('.json','.log','.guard.json')):
    raise FileExistsError('Evidence already exists')
report=supervise(command,args.output,ExperimentLimits(admitted_payload_bytes=args.payload_mib<<20,timeout_seconds=900),
    env=dict(os.environ,PYTHONPATH=str(ROOT/'airllm-next/air_llm'),MLX_ENABLE_TF32='0',OMP_NUM_THREADS='1',
             OPENBLAS_NUM_THREADS='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1'))
args.output.write_text(json.dumps(dict(status='completed',guard=report),indent=2)+'\n')
