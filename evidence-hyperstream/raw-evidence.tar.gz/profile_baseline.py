import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'baseline'
OUT = ROOT / 'profile-baseline-3'
OUT.mkdir(exist_ok=True)
sys.path.insert(0, str(REPO / 'air_llm'))
from airllm.nextgen.experiment_guard import ExperimentLimits, supervise, system_snapshot

tasks = OUT / 'tasks.json'
tasks.write_text(json.dumps([dict(id='short', prompt='Combien font 17 + 25 ? Réponds seulement par le nombre.', max_new_tokens=32)], ensure_ascii=False))
print(json.dumps(system_snapshot()), flush=True)
command = [sys.executable, '-m', 'cProfile', '-o', str(OUT/'profile.pstats'), str(REPO/'benchmarks/benchmark_research51.py'),
    '--worker', '--model', '/Users/macbook/.ollama/models/blobs/sha256-f5ee307a2982106a6eb82b62b2c00b575c9072145a759ae4660378acda8dcf2d',
    '--tasks', str(tasks), '--output', str(OUT/'result.json'), '--engine-root', str(REPO), '--label', 'profile-baseline',
    '--expert-batch', '--concat-tiles', '--packed-direct-io', '--bulk-metadata', '--zero-copy-weights']
supervise(command, OUT/'result.json', ExperimentLimits(), env=dict(os.environ, MLX_ENABLE_TF32='0', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', PYTHONDONTWRITEBYTECODE='1'))
