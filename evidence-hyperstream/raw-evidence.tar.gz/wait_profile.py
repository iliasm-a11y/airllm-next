"""One bounded attempt after a sustained safe resource window; no app shutdowns."""
import json
from pathlib import Path
import runpy
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'baseline/air_llm'))
from airllm.nextgen.experiment_guard import system_snapshot

begin = time.monotonic()
stable = None
samples = []
for _ in range(49):
    snapshot = system_snapshot()
    elapsed = time.monotonic()-begin
    samples.append(dict(elapsed=elapsed, **snapshot))
    print(json.dumps(samples[-1]), flush=True)
    good = snapshot['pressure_level'] == 1 and snapshot['available_bytes'] >= (4608 << 20)
    stable = (stable if stable is not None else time.monotonic()) if good else None
    if stable is not None and time.monotonic()-stable >= 15:
        (ROOT/'resource-window.json').write_text(json.dumps(dict(status='safe_window', samples=samples), indent=2))
        runpy.run_path(str(ROOT/'profile_baseline.py'), run_name='__main__')
        break
    if elapsed >= 240:
        (ROOT/'resource-window.json').write_text(json.dumps(dict(status='deferred', samples=samples), indent=2))
        break
    time.sleep(5)
